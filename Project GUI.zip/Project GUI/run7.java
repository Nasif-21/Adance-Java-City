public class run7 
{
	public static void main(String [] args)
	{
		Rules d1 = new Rules();
		d1.show();
		//f1.setVisible(true);
	}
}
