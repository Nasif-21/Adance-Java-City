public class elect 
{
	public static void main(String [] args)
	{
	       Current a1 = new Current();
		   a1.show();
		//f1.setVisible(true);
	}
}