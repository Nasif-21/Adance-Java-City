import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class Edu extends JFrame implements ActionListener
{
  JLabel l1,l2,l3,l4,l5,l6,l7,l8,l9,l10;
  JPanel p1,p2;
  JButton b1;
  JTable t1;

  public Edu()
  {
  	super("Education Institute List");
	this.setSize(800,700);
	this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	    p1 = new JPanel();
		p1.setSize(new Dimension(800,700));
		p1.setBackground(Color.white);
		p1.setLayout(null);

		l1 = new JLabel(" Education Institute list ");
		l1.setFont(new Font("Serif",Font.BOLD,30));
		l1.setForeground(Color.YELLOW);
		l1.setBounds(190,30,350,50);
		p1.add(l1);
        
        l2 = new JLabel("Tanha International college   | Farmgate ");
		l2.setFont(new Font("Comic Sans MS",Font.PLAIN,15));
		l2.setForeground(Color.red);
		l2.setBounds(180,100,350,20);
		p1.add(l2);
		
		l3 = new JLabel("Thamid Institue of Technology  | Mirpur 14");
		l3.setFont(new Font("Comic Sans MS",Font.PLAIN,15));
		l3.setForeground(Color.blue);
		l3.setBounds(180,150,350,20);
		p1.add(l3);
		
        l4 = new JLabel("Nasif Uddin International School  | Shewapara");
		l4.setFont(new Font("Comic Sans MS",Font.PLAIN,15));
		l4.setForeground(Color.green);
		l4.setBounds(180,200,350,20);
		p1.add(l4);

		l5 = new JLabel("Rufaida University of Medical Science | Uttara");
		l5.setFont(new Font("Comic Sans MS",Font.PLAIN,15));
		l5.setForeground(Color.blue);
		l5.setBounds(180,250,350,20);
		p1.add(l5);

		l6 = new JLabel("F.Bin Abdullah International University | Gulshan");
		l6.setFont(new Font("Comic Sans MS",Font.PLAIN,15));
		l6.setForeground(Color.red);
		l6.setBounds(180,300,350,20);
		p1.add(l6);

		l7 = new JLabel("Sheikh Institute of Textile    |    Banani");
		l7.setFont(new Font("Comic Sans MS",Font.PLAIN,15));
		l7.setForeground(Color.black);
		l7.setBounds(180,350,350,20);
		p1.add(l7);

        l8 = new JLabel("Salim Sadman  Modern School     |  Gulistan");
		l8.setFont(new Font("Comic Sans MS",Font.PLAIN,15));
		l8.setForeground(Color.red);
		l8.setBounds(180,400,350,20);
		p1.add(l8);

		l9 = new JLabel("NTTR Atomic Science Research Institute | Cankharpur");
		l9.setFont(new Font("Comic Sans MS",Font.PLAIN,15));
		l9.setForeground(Color.blue);
		l9.setBounds(180,450,450,20);
		p1.add(l9);

		
        
        b1 = new JButton("Main Menu");
		b1.setFont(new Font("Comic Sans MS",Font.BOLD,15));
		b1.setForeground(Color.black);
		b1.setBounds(250,500,200,25);
		b1.addActionListener(this);
		
		p1.add(b1);

		this.add(p1);


  }
  public void actionPerformed(ActionEvent ae)
    {
    	if(ae.getSource()==b1)
			{
			Student st=new Student();
            this.setVisible(false);
            st.setVisible(true);
			}
    }
}