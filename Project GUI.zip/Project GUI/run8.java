public class run8
{
	public static void main(String [] args)
	{
		Bank v1 = new Bank();
		v1.show();
		//f1.setVisible(true);
	}
}