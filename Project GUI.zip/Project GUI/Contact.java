import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Contact extends JFrame implements ActionListener
{
		JLabel l1,l2,l3,l4;
		JTextField t1,t2,t3;
		JButton b1,b2; 
		JPanel p1;
		
	public Contact()
	{
		super(" P ");
		this.setSize(800,700);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		p1 = new JPanel();
		p1.setSize(new Dimension(800,700));
		p1.setBackground(Color.white);
		p1.setLayout(null);
		
		l1 = new JLabel("Contact");
		l1.setFont(new Font("Serif",Font.BOLD,40));
		l1.setForeground(Color.BLUE);
		l1.setBounds(200,30,150,30);
		p1.add(l1);
		
		l2 = new JLabel("Name :");
		l2.setFont(new Font("Comic Sans MS",Font.PLAIN,15));
		l2.setForeground(Color.green);
		l2.setBounds(100,100,190,20);
		p1.add(l2);
		
		l3 = new JLabel("Phone Number :");
		l3.setFont(new Font("Comic Sans MS",Font.PLAIN,15));
		l3.setForeground(Color.red);
		l3.setBounds(100,200,250,20);
		p1.add(l3);

		l4 = new JLabel("Address :");
		l4.setFont(new Font("Comic Sans MS",Font.PLAIN,15));
		l4.setForeground(Color.red);
		l4.setBounds(100,300,250,20);
		p1.add(l4);
		
		t1 = new JTextField();
		t1.setBounds(220,100,150,25);
		p1.add(t1);

		t2 = new JTextField();
		t2.setBounds(220,300,150,25);
		p1.add(t2);

		t3 = new JTextField();
		t3.setBounds(220,200,150,25);
		p1.add(t3);
		
		b1 = new JButton("Submit");
		b1.setFont(new Font("Comic Sans MS",Font.BOLD,15));
		b1.setForeground(Color.green);
		b1.setBackground(Color.black);
		b1.setBounds(150,400,150,40);
		b1.addActionListener(this);
		p1.add(b1);

		
		b2 = new JButton("Main Menu");
		b2.setFont(new Font("Comic Sans MS",Font.BOLD,15));
		b2.setForeground(Color.white);
		b2.setBackground(Color.green);
		b2.setBounds(330,400,200,40);
		b2.addActionListener(this);
		p1.add(b2);	
		
        this.add(p1);		
        
	}
     public void actionPerformed(ActionEvent ae)
		{
			if(ae.getSource()==b1)
			{
			Submit s1=new Submit();
			s1.show();
			}
			else if(ae.getSource()==b2)
			{
				Police s1=new Police ();
				s1.show();
			}
		}

		


}


		







