import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.ImageIcon;
public class Signin extends JFrame implements ActionListener
{
		JLabel l1,l2,l3,l4,l5,l6,l7,l8;
		JTextField t1,t2,t3,t4,t5,t6,t7;
		JButton b1; 
		JPanel p1,p2;
        ImageIcon i1;
		
	public Signin()
	{
		super("\t Sign Up \t");
		this.setSize(800,700);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		p1 = new JPanel();
		p1.setSize(new Dimension(800,400));
		p1.setBackground(Color.white);
		p1.setLayout(null);
		ImageIcon i1=new ImageIcon("D:/Project GUI/Image/City.jpg");
		

		l1 = new JLabel(" Sign Up  ");
		l1.setFont(new Font("Serif",Font.BOLD,30));
		l1.setForeground(Color.YELLOW);
		l1.setBounds(280,30,300,50);
		p1.add(l1);
		
		l2 = new JLabel(" Name :");
		l2.setFont(new Font("Comic Sans MS",Font.PLAIN,15));
		l2.setForeground(Color.white);
		l2.setBounds(180,100,150,20);
		p1.add(l2);
		
		l3 = new JLabel("Date of birth :");
		l3.setFont(new Font("Comic Sans MS",Font.PLAIN,15));
		l3.setForeground(Color.white);
		l3.setBounds(180,150,150,20);
		p1.add(l3);
		
        l4 = new JLabel("City :");
		l4.setFont(new Font("Comic Sans MS",Font.PLAIN,15));
		l4.setForeground(Color.white);
		l4.setBounds(180,200,150,20);
		p1.add(l4);

		l5 = new JLabel("Gender :");
		l5.setFont(new Font("Comic Sans MS",Font.PLAIN,15));
		l5.setForeground(Color.white);
		l5.setBounds(180,250,150,20);
		p1.add(l5);

		l6 = new JLabel("Password :");
		l6.setFont(new Font("Comic Sans MS",Font.PLAIN,15));
		l6.setForeground(Color.white);
		l6.setBounds(180,300,150,20);
		p1.add(l6);

		l7 = new JLabel("Age :");
		l7.setFont(new Font("Comic Sans MS",Font.PLAIN,15));
		l7.setForeground(Color.white);
		l7.setBounds(180,350,200,20);
		p1.add(l7);

		

		t1 = new JTextField();
		t1.setBounds(300,100,200,25);
		p1.add(t1);

		t2 = new JTextField();
		t2.setBounds(300,150,200,25);
		p1.add(t2);
		
        t3 = new JTextField();
		t3.setBounds(300,150,200,25);
		p1.add(t3);

		t4 = new JTextField();
		t4.setBounds(300,200,200,25);
		p1.add(t4);

		t5 = new JTextField();
		t5.setBounds(300,250,200,25);
		p1.add(t5);

		t6 = new JTextField();
		t6.setBounds(300,300,200,25);
		p1.add(t6);

		t7 = new JTextField();
		t7.setBounds(300,350,200,25);
		p1.add(t7);

		b1 = new JButton("Next");
		b1.setFont(new Font("Comic Sans MS",Font.BOLD,15));
		b1.setForeground(Color.green);
		b1.setBounds(350,400,100,25);
		b1.addActionListener(this);
		
		p1.add(b1);

		l8 = new JLabel(i1);
		l8.setBounds(0,0,800,700);
		p1.add(l8);		
		
	    	
		
        this.add(p1);		
       
	}
    public void actionPerformed(ActionEvent ae)
    {
    	if(ae.getSource()==b1)
			{
			
				Login l = new Login();
				this.setVisible(false);
				l.setVisible(true);
			}
    }
		


}