
public class t4
{
	public static void main(String [] args)
	{
		Famous p=new Famous();
		p.show();
		
	}
}