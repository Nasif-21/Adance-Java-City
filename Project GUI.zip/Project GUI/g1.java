public class g1 
{
	public static void main(String [] args)
	{
		Gas c1 = new Gas();
		c1.show();
		//f1.setVisible(true);
	}
}
