public class run1 
{
	public static void main(String [] args)
	{
		Contact s1 = new Contact();
		s1.show();
		//f1.setVisible(true);
	}
}