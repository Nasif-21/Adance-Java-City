import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

 

public class Internet extends JFrame implements ActionListener
{
        JLabel l1,l2,l3,l4,l5;
        JTextField t1,t2;
        JButton b1,b2,b3; 
        JPanel p1;    
    public Internet()
    {
        super(" Internet ");
        this.setSize(800,700);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        p1 = new JPanel();
        p1.setSize(new Dimension(800,700));
        p1.setBackground(Color.white);
        p1.setLayout(null);
        
        l1 = new JLabel("Internet and Telephone service");
        l1.setFont(new Font("Serif",Font.BOLD,40));
        l1.setForeground(Color.BLUE);
        l1.setBounds(100,30,450,30);
        p1.add(l1);
        
        l3 = new JLabel("Month :");
        l3.setFont(new Font("Comic Sans MS",Font.PLAIN,15));
        l3.setForeground(Color.blue);
        l3.setBounds(100,120,100,20);
        p1.add(l3);
        
        l4 = new JLabel("Permonth :");
        l4.setFont(new Font("Comic Sans MS",Font.PLAIN,15));
        l4.setForeground(Color.blue);
        l4.setBounds(100,170,150,20);
        p1.add(l4);
        
        t1 = new JTextField();
        t1.setBounds(220,120,100,20);
        p1.add(t1);

 

 

 

        t2 = new JTextField();
        t2.setBounds(220,170,100,20);
        p1.add(t2);
        
        b1 = new JButton("Bill");
        b1.setFont(new Font("Comic Sans MS",Font.BOLD,15));
        b1.setForeground(Color.green);
        b1.setBounds(180,220,100,25);
        b1.addActionListener(this);
        p1.add(b1);

 

        
        l5 = new JLabel();
        l5.setFont(new Font("Comic Sans MS",Font.BOLD,20));
        l5.setForeground(Color.pink);
        l5.setBounds(180,270,150,20);
        p1.add(l5);
        
        b2 = new JButton("Exit");
        b2.setFont(new Font("Comic Sans MS",Font.BOLD,15));
        b2.setForeground(Color.white);
        b2.setBackground(Color.green);
        b2.setBounds(330,320,100,30);
        b2.addActionListener(this);
        p1.add(b2);
        
        b3 = new JButton("Main Menu");
        b3.setFont(new Font("Comic Sans MS",Font.BOLD,15));
        b3.setForeground(Color.white);
        b3.setBackground(Color.green);
        b3.setBounds(90,320,200,30);
        b3.addActionListener(this);
        p1.add(b3);

        
        this.add(p1);        
       
    }

 

 

 

        public void actionPerformed(ActionEvent ae)
        {
            if(ae.getSource()==b1)
            {
            int a = Integer.parseInt(t1.getText());
            int b = Integer.parseInt(t2.getText());
            int s= a*b;
            l5.setText("Bill : "+String.valueOf(s));
            }

            else if(ae.getSource()==b2)
            {
                System.exit(0);
            
            }

            else if(ae.getSource()==b3)
            {
            Permanent pr=new Permanent();
            this.setVisible(false);
            pr.setVisible(true);
            }


            
        }

 

 

 


}