
public class h1
{
	public static void main(String [] args)
	{
		House h=new House();
		h.show();
		
	}
}