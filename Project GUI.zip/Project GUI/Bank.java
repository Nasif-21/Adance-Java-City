import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Bank extends JFrame implements ActionListener
{
		JLabel l1;
		
		JButton b1,b2,b3,b4; 
		JPanel p1;
		
	public Bank()
	{
		super("b-1 ");
		this.setSize(800,700);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		p1 = new JPanel();
		p1.setSize(new Dimension(800,700));
		p1.setBackground(Color.white);
		p1.setLayout(null);
		
		l1 = new JLabel("Bank Service");
		l1.setFont(new Font("Serif",Font.BOLD,40));
		l1.setForeground(Color.BLUE);
		l1.setBounds(220,30,400,40);
		p1.add(l1);

		b1 = new JButton("Withdraw");
		b1.setFont(new Font("Comic Sans MS",Font.BOLD,15));
		b1.setForeground(Color.black);
		b1.setBounds(220,100,190,40);
		b1.addActionListener(this);
		p1.add(b1);

		b2 = new JButton("Diposit");
		b2.setFont(new Font("Comic Sans MS",Font.BOLD,15));
		b2.setForeground(Color.black);
		b2.setBounds(220,150,190,40);
		b2.addActionListener(this);
		p1.add(b2);

		b3 = new JButton("Loan");
		b3.setFont(new Font("Comic Sans MS",Font.BOLD,15));
		b3.setForeground(Color.black);
		b3.setBounds(220,200,190,40);
		b3.addActionListener(this);
		p1.add(b3);

		b4= new JButton(" Main Menu");
		b4.setFont(new Font("Comic Sans MS",Font.BOLD,15));
		b4.setForeground(Color.black);
		b4.setBounds(220,250,190,40);
		b4.addActionListener(this);
		p1.add(b4);

		

		this.add(p1);
	}
	public void actionPerformed(ActionEvent ae)
		{
		   if(ae.getSource()==b1)
			{
			  Withdraw k1 = new Withdraw();
		        k1.show();
			}
			
			else if(ae.getSource()==b2)
			{
				Deposit d1 = new Deposit();
		           d1.show();
			}
			else if(ae.getSource()==b3)
			{
				Loan s1 = new Loan();
		           s1.show();
		
			}
			else if(ae.getSource()==b4)
			{
				Permanent e1 = new Permanent();
		               e1.show();
			}
		}

}