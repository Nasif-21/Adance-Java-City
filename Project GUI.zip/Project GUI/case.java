public class case 
{
	public static void main(String [] args)
	{
		Complain o1 = new Complain();
		o1.show();
		//f1.setVisible(true);
	}
}
