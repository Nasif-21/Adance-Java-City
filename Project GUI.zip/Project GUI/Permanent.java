import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Permanent extends JFrame  implements ActionListener
{
  JButton b1,b2,b3,b4,b5,b6,b7,b8,b9;
  JPanel p1,p2;
  JLabel l1,l2;
   public Permanent()
    {
        super(" Permanent ");
        this.setSize(800,700);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        p1 = new JPanel();
		p1.setSize(new Dimension(800,700));
		p1.setBackground(Color.WHITE);
		p1.setLayout(null);

        b1 = new JButton("Bank Servive");
		b1.setFont(new Font("Comic Sans MS",Font.BOLD,15));
		b1.setForeground(Color.yellow);
		b1.setBounds(300,100,250,30);
		b1.addActionListener(this);
		p1.add(b1);

		b2 = new JButton("Gas service");
		b2.setFont(new Font("Comic Sans MS",Font.BOLD,15));
		b2.setForeground(Color.red);
		b2.setBounds(300,150,250,30);
		b2.addActionListener(this);
		p1.add(b2);

		b3 = new JButton("Electric Service");
		b3.setFont(new Font("Comic Sans MS",Font.BOLD,15));
		b3.setForeground(Color.pink);
		b3.setBounds(300,200,250,30);
		b3.addActionListener(this);
		p1.add(b3);

		b4 = new JButton("Police Service");
		b4.setFont(new Font("Comic Sans MS",Font.BOLD,15));
		b4.setForeground(Color.blue);
		b4.setBounds(300,250,250,30);
		b4.addActionListener(this);
		p1.add(b4);

		b5 = new JButton("Internet and Telephone Service");
		b5.setFont(new Font("Comic Sans MS",Font.BOLD,15));
		b5.setForeground(Color.orange);
		b5.setBounds(300,300,250,30);
		b5.addActionListener(this);
		p1.add(b5);

		b6 = new JButton("Airline Service");
		b6.setFont(new Font("Comic Sans MS",Font.BOLD,15));
		b6.setForeground(Color.green);
		b6.setBounds(300,350,250,30);
		b6.addActionListener(this);
		p1.add(b6);

		b7 = new JButton("Complain & Suggesition");
		b7.setFont(new Font("Comic Sans MS",Font.BOLD,15));
		b7.setForeground(Color.red);
		b7.setBounds(300,400,250,30);
		b7.addActionListener(this);
		p1.add(b7);

		b8 = new JButton("EXIT");
		b8.setFont(new Font("Comic Sans MS",Font.BOLD,15));
		b8.setForeground(Color.BLACK);
		b8.setBounds(350,450,100,25);
		b8.addActionListener(this);
		p1.add(b8);

        


		this.add(p1);
		
	}
  public void actionPerformed(ActionEvent ae)
    {
        if(ae.getSource()==b8)
            {
            
                System.exit(0);
            }
            else if(ae.getSource()==b2)
            {
              Gas c1 = new Gas();
		          c1.show();
            }
            else if(ae.getSource()==b3)
            {
                 Current a1 = new Current();
		           a1.show();
            }
             else if(ae.getSource()==b1)
             {
             	Bank v1 = new Bank();
		          v1.show();
             }
              else if(ae.getSource()==b4)
              {
              	Police s1 = new Police();
		            s1.show();
              }
              else if(ae.getSource()==b6)
              {
              	Airlines e1 = new Airlines();
		             e1.show();
              }
               else if(ae.getSource()==b5)
           {

              Internet t1 = new Internet();
		           t1.show();
		      }
		       else if(ae.getSource()==b7)
		       {
                  Suggestion g1 = new Suggestion();
		                g1.show();
		       }
    }


}