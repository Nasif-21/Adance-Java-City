
public class stu1
{
	public static void main(String [] args)
	{
		Student st=new Student();
		st.show();
		
	}
}