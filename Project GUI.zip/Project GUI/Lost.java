import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Lost extends JFrame implements ActionListener
{
		JLabel l1,l2,l3;
		JTextField t1,t2;
		JButton b1,b2; 
		JPanel p1;
		public Lost()
	{
		super("Case-3 ");
		this.setSize(800,700);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		p1 = new JPanel();
		p1.setSize(new Dimension(800,700));
		p1.setBackground(Color.white);
		p1.setLayout(null);
		
		l1 = new JLabel("Lost Case ");
		l1.setFont(new Font("Serif",Font.BOLD,40));
		l1.setForeground(Color.BLUE);
		l1.setBounds(220,30,300,40);
		p1.add(l1);

		l2 = new JLabel(" Lost Item :");
		l2.setFont(new Font("Serif",Font.BOLD,20));
		l2.setForeground(Color.BLUE);
		l2.setBounds(180,120,200,45);
		p1.add(l2);

		l3 = new JLabel("Complain :");
		l3.setFont(new Font("Serif",Font.BOLD,20));
		l3.setForeground(Color.BLUE);
		l3.setBounds(180,180,300,60);
		p1.add(l3);

		t1 = new JTextField();
		t1.setBounds(320,130,200,25);
		p1.add(t1);

		t2 = new JTextField();
		t2.setBounds(300,185,250,70);
		p1.add(t2);

		b1 = new JButton("Main Menu");
		b1.setFont(new Font("Comic Sans MS",Font.BOLD,15));
		b1.setForeground(Color.green);
		b1.setBackground(Color.black);
		b1.setBounds(300,400,190,40);
		b1.addActionListener(this);
		p1.add(b1);

		b2 = new JButton("Submit");
		b2.setFont(new Font("Comic Sans MS",Font.BOLD,15));
		b2.setForeground(Color.green);
		b2.setBackground(Color.black);
		b2.setBounds(130,400,140,40);
		b2.addActionListener(this);
		p1.add(b2);

		this.add(p1);
	}
	public void actionPerformed(ActionEvent ae)
		{
			if(ae.getSource()==b1)
			{
			
			  Police s1 = new Police();
		       s1.show();
			}
			else if(ae.getSource()==b2)
			{
				Submit n1= new Submit();
				n1.show();
			}
		}

}