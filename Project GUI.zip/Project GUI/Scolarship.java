import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Scolarship extends JFrame implements ActionListener
{
		JLabel l1,l2,l3,l4,l5,l6,l7,l8;
		JTextField t1,t2,t3,t4,t5,t6,t7;
		JButton b1,b2; 
		JPanel p1,p2;
		
	public Scolarship()
	{
		super("\t Scolarship \t");
		this.setSize(800,700);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		p1 = new JPanel();
		p1.setSize(new Dimension(800,400));
		p1.setBackground(Color.white);
		p1.setLayout(null);
		
		l1 = new JLabel(" Give your board exam result ");
		l1.setFont(new Font("Serif",Font.BOLD,30));
		l1.setForeground(Color.BLUE);
		l1.setBounds(200,30,400,50);
		p1.add(l1);
		
		l2 = new JLabel(" PSC  :");
		l2.setFont(new Font("Comic Sans MS",Font.PLAIN,15));
		l2.setForeground(Color.red);
		l2.setBounds(180,100,150,20);
		p1.add(l2);
		
		l3 = new JLabel("JSC   :");
		l3.setFont(new Font("Comic Sans MS",Font.PLAIN,15));
		l3.setForeground(Color.red);
		l3.setBounds(180,150,150,20);
		p1.add(l3);
		
        l4 = new JLabel("SSC :");
		l4.setFont(new Font("Comic Sans MS",Font.PLAIN,15));
		l4.setForeground(Color.red);
		l4.setBounds(180,200,150,20);
		p1.add(l4);

		l5 = new JLabel("HSC :");
		l5.setFont(new Font("Comic Sans MS",Font.PLAIN,15));
		l5.setForeground(Color.red);
		l5.setBounds(180,250,150,20);
		p1.add(l5);

		l6 = new JLabel();
		l6.setFont(new Font("Comic Sans MS",Font.PLAIN,15));
		l6.setForeground(Color.red);
		l6.setBounds(200,300,150,20);
		p1.add(l6);

		l7 = new JLabel();
		l7.setFont(new Font("Comic Sans MS",Font.PLAIN,15));
		l7.setForeground(Color.red);
		l7.setBounds(250,350,400,20);
		p1.add(l7);

		t1 = new JTextField();
		t1.setBounds(300,100,200,25);
		p1.add(t1);

		t2 = new JTextField();
		t2.setBounds(300,150,200,25);
		p1.add(t2);
		
        t3 = new JTextField();
		t3.setBounds(300,200,200,25);
		p1.add(t3);

		t4 = new JTextField();
		t4.setBounds(300,250,200,25);
		p1.add(t4);

		

		b1 = new JButton("Check");
		b1.setFont(new Font("Comic Sans MS",Font.BOLD,15));
		b1.setForeground(Color.blue);
		b1.setBounds(330,400,100,25);
		b1.addActionListener(this);
        p1.add(b1);

		b2 = new JButton("Student Menu");
		b2.setFont(new Font("Comic Sans MS",Font.BOLD,15));
		b2.setForeground(Color.green);
		b2.setBounds(90,400,200,25);
		b2.addActionListener(this);
        p1.add(b2);
		

				
		
	    	
		
        this.add(p1);		
       
	}
    public void actionPerformed(ActionEvent ae)
    {
    	if(ae.getSource()==b1)
			{
			double a=Double.parseDouble(t1.getText());
			double b=Double.parseDouble(t2.getText());
			double c=Double.parseDouble(t3.getText());
			double d=Double.parseDouble(t4.getText());
			double total=a+b+c+d;
			l6.setText("Total GPA : "+String.valueOf(total));
			if(total<=20)
			{
				l7.setText("You are eligible for 100% Scolarship");
			}
			else if(total>=17 && total<=19)
			{
				l7.setText("You are eligible for 80% Scolarship");
			}
			else if(total>=15 && total<=16)
			{
				l7.setText("You are eligible for 80% Scolarship");
			}
			else
			{
            l7.setText("Sorry, you are not eligible for Scolarship");
			}	
			}
			else if(ae.getSource()==b2)
			{
            Student st=new Student();
            this.setVisible(false);
            st.setVisible(true);
			}
			}
			}

    
		
