import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Airlines extends JFrame  implements ActionListener
{
  JButton b1,b2,b3,b4;
  JPanel p1;
  JLabel l1;
   public Airlines()
    {
        super(" Airlines ");
        this.setSize(800,700);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        p1 = new JPanel();
		    p1.setSize(new Dimension(800,700));
		    p1.setBackground(Color.WHITE);
		    p1.setLayout(null);

        l1 = new JLabel("Welcome to Air portal");
        l1.setFont(new Font("Serif",Font.BOLD,40));
        l1.setForeground(Color.BLUE);
        l1.setBounds(180,30,500,50);
        p1.add(l1);

    

        b1 = new JButton("Domestic");
		b1.setFont(new Font("Comic Sans MS",Font.BOLD,15));
		b1.setForeground(Color.green);
		b1.setBounds(300,100,350,60);
		b1.addActionListener(this);
		p1.add(b1);

		b2 = new JButton("International");
		b2.setFont(new Font("Comic Sans MS",Font.BOLD,15));
		b2.setForeground(Color.blue);
		b2.setBounds(300,200,350,60);
		b2.addActionListener(this);
		p1.add(b2);

		b3 = new JButton("Main menu");
		b3.setFont(new Font("Comic Sans MS",Font.BOLD,15));
		b3.setForeground(Color.red);
		b3.setBounds(300,300,350,60);
		b3.addActionListener(this);
		p1.add(b3);

		b4 = new JButton("EXIT");
		b4.setFont(new Font("Comic Sans MS",Font.BOLD,15));
		b4.setForeground(Color.BLACK);
		b4.setBounds(350,400,100,25);
		b4.addActionListener(this);
		p1.add(b4);
		this.add(p1);
	}
  public void actionPerformed(ActionEvent ae)
    {
        if(ae.getSource()==b1)
            {
             Domestic d=new Domestic();
             this.setVisible(false);
             d.setVisible(true);
            }
            else if(ae.getSource()==b2)
            {
            	International in=new International();
            	this.setVisible(false);
            	in.setVisible(true);
            }
            else if(ae.getSource()==b3)
            {
            Permanent pr=new Permanent();
            this.setVisible(false);
            pr.setVisible(true);
            }
            
            else if(ae.getSource()==b4)
            {
            	System.exit(0);
            }
    }


}