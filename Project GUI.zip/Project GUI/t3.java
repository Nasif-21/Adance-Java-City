
public class t3
{
	public static void main(String [] args)
	{
		Hotel ht = new Hotel();
		ht.show();
		
	}
}