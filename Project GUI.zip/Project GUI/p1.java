public class p1
{
	public static void main(String [] args)
	{
		Permanent e1 = new Permanent();
		e1.show();
		
	}
}