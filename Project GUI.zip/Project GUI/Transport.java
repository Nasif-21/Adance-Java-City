import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Transport extends JFrame  implements ActionListener
{
  JButton b1,b2,b3,b4,b5,b6,b7,b8,b9,b10,b11,b12,b13;
  JPanel p1,p2;
  JLabel l1,l6,l7;
  JTextField t1,t2;
   public Transport()
    {
        super(" Transport ");
        this.setSize(800,700);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        p1 = new JPanel();
        p1.setSize(new Dimension(800,700));
        p1.setBackground(Color.WHITE);
        p1.setLayout(null);

        l1 = new JLabel(" Select your Transport");
        l1.setFont(new Font("Serif",Font.BOLD,30));
        l1.setForeground(Color.BLUE);
        l1.setBounds(200,30,500,50);
        p1.add(l1);
        

        b1 = new JButton("Bus Facility");
        b1.setFont(new Font("Comic Sans MS",Font.BOLD,15));
        b1.setForeground(Color.black);
        b1.setBounds(100,100,500,30);
        b1.addActionListener(this);
        p1.add(b1);

        b2 = new JButton("Motorcycle");
        b2.setFont(new Font("Comic Sans MS",Font.BOLD,15));
        b2.setForeground(Color.red);
        b2.setBounds(100,150,500,30);
        b2.addActionListener(this);
        p1.add(b2);

        b3 = new JButton("Train Facility");
        b3.setFont(new Font("Comic Sans MS",Font.BOLD,15));
        b3.setForeground(Color.pink);
        b3.setBounds(100,200,500,30);
        b3.addActionListener(this);
        p1.add(b3);

        b4 = new JButton("Cab Facility");
        b4.setFont(new Font("Comic Sans MS",Font.BOLD,15));
        b4.setForeground(Color.blue);
        b4.setBounds(100,250,500,30);
        b4.addActionListener(this);
        p1.add(b4);

        b5 = new JButton("Airlines");
        b5.setFont(new Font("Comic Sans MS",Font.BOLD,15));
        b5.setForeground(Color.green);
        b5.setBounds(100,300,500,30);
        b5.addActionListener(this);
        p1.add(b5);

        l6 = new JLabel("Number of persons :");
        l6.setFont(new Font("Comic Sans MS",Font.PLAIN,15));
        l6.setForeground(Color.red);
        l6.setBounds(100,350,250,20);
        p1.add(l6);

        

        t2 = new JTextField();
        t2.setBounds(300,350,200,25);
        p1.add(t2);

        b12 = new JButton("Main Menu");
        b12.setFont(new Font("Comic Sans MS",Font.BOLD,15));
        b12.setForeground(Color.BLACK);
        b12.setBounds(100,450,250,25);
        b12.addActionListener(this);
        p1.add(b12);

        b13 = new JButton("EXIT");
        b13.setFont(new Font("Comic Sans MS",Font.BOLD,15));
        b13.setForeground(Color.BLACK);
        b13.setBounds(400,450,100,25);
        b13.addActionListener(this);
        p1.add(b13);

        l6 = new JLabel();
        l6.setFont(new Font("Serif",Font.BOLD,30));
        l6.setForeground(Color.BLUE);
        l6.setBounds(200,500,500,50);
        p1.add(l6);

        l7 = new JLabel();
        l7.setFont(new Font("Serif",Font.BOLD,30));
        l7.setForeground(Color.BLUE);
        l7.setBounds(200,550,500,50);
        p1.add(l7);


        this.add(p1);
        
    }
  public void actionPerformed(ActionEvent ae)
    {
        if(ae.getSource()==b13)
            {
            
                System.exit(0);
            }
            else if(ae.getSource()==b1)
            {
            int a =Integer.parseInt(t2.getText());
            
            int total=a*100;
            l6.setText("Select Bus");
            l7.setText("Total fair  : "+String.valueOf(total));

            }
            else if(ae.getSource()==b12)
            {
            Tourist tr=new Tourist();
            this.setVisible(false);
            tr.setVisible(true);
            }
            else if(ae.getSource()==b2)
            {
            int a = Integer.parseInt(t2.getText());
            if(a<2){
            int total=a*200;
            l6.setText("Select Motorcycle ");
            l7.setText("Total fair  : "+String.valueOf(total));
            }
            else
            {
                l6.setText("Select Motorcycle ");
             l7.setText("More than 1 person is prohibited");
            }
            }
            else if(ae.getSource()==b3)
            {
            int a = Integer.parseInt(t2.getText());
            
            int total=a*100;
            l6.setText("Select Train ");
            l7.setText("Total fair  : "+String.valueOf(total));
            }
            else if(ae.getSource()==b4)
            {
            int a = Integer.parseInt(t2.getText());
            
            int total=a*150;
            l6.setText("Select Cab");
            l7.setText("Total fair  : "+String.valueOf(total));
            }
            else if(ae.getSource()==b5)
            {
            int a = Integer.parseInt(t2.getText());
            
            int total=a*2500;
            l6.setText("Select Airlines");
            l7.setText("Total fair  : "+String.valueOf(total));
            }

    }


}