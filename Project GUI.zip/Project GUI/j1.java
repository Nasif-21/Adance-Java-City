
public class j1
{
	public static void main(String [] args)
	{
		 Edu ed=new Edu();
		ed.show();
		
	}
}