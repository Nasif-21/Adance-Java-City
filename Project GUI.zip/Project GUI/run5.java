public class run5 
{
	public static void main(String [] args)
	{
		Lost u1 = new Lost();
		u1.show();
		//f1.setVisible(true);
	}
}
