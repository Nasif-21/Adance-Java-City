
public class sco
{
	public static void main(String [] args)
	{
		Scolarship r=new Scolarship();
		r.show();
		
	}
}