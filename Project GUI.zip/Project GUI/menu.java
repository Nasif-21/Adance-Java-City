public class menu 
{
	public static void main(String [] args)
	{
		Police s1 = new Police();
		s1.show();
		//f1.setVisible(true);
	}
}