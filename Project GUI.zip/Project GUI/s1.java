public class s1
{
	public static void main(String [] args)
	{
		Suggestion g1 = new Suggestion();
		g1.show();
		
	}
}