
public class a1
{
	public static void main(String [] args)
	{
		Airlines e1 = new Airlines();
		e1.show();
		
	}
}