public class e1
{
	public static void main(String [] args)
	{
		Internet t1 = new Internet();
		t1.show();
		
	}
}