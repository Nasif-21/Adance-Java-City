import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class House extends JFrame  implements ActionListener
{
  JButton b1,b2,b3,b4,b5,b6,b7,b8,b9,b10,b11,b12,b13;
  JPanel p1,p2;
  JLabel l1,l2;
   public House()
    {
        super(" Home ");
        this.setSize(800,700);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        p1 = new JPanel();
		p1.setSize(new Dimension(800,700));
		p1.setBackground(Color.WHITE);
		p1.setLayout(null);

		l1 = new JLabel(" Select your new home location ");
		l1.setFont(new Font("Serif",Font.BOLD,35));
		l1.setForeground(Color.BLUE);
		l1.setBounds(100,30,500,50);
		p1.add(l1);
		

        b1 = new JButton("Mirpur : fair 13000 BDT per month ");
		b1.setFont(new Font("Comic Sans MS",Font.BOLD,15));
		b1.setForeground(Color.black);
		b1.setBounds(100,100,500,30);
		b1.addActionListener(this);
		p1.add(b1);

		b2 = new JButton("Gulshan :fair 12000 BDT per month");
		b2.setFont(new Font("Comic Sans MS",Font.BOLD,15));
		b2.setForeground(Color.red);
		b2.setBounds(100,150,500,30);
		b2.addActionListener(this);
		p1.add(b2);

		b3 = new JButton("Dhandondi:fair 15000 BDT per month");
		b3.setFont(new Font("Comic Sans MS",Font.BOLD,15));
		b3.setForeground(Color.pink);
		b3.setBounds(100,200,500,30);
		b3.addActionListener(this);
		p1.add(b3);

		b4 = new JButton("Cantonment :fair 18000 BDT per month");
		b4.setFont(new Font("Comic Sans MS",Font.BOLD,15));
		b4.setForeground(Color.blue);
		b4.setBounds(100,250,500,30);
		b4.addActionListener(this);
		p1.add(b4);

		b5 = new JButton("Uttara :fair 24000 BDT per month");
		b5.setFont(new Font("Comic Sans MS",Font.BOLD,15));
		b5.setForeground(Color.orange);
		b5.setBounds(100,300,500,30);
		b5.addActionListener(this);
		p1.add(b5);

		b6 = new JButton("Basundhara:fair 20000 BDT per month");
		b6.setFont(new Font("Comic Sans MS",Font.BOLD,15));
		b6.setForeground(Color.green);
		b6.setBounds(100,350,500,30);
		b6.addActionListener(this);
		p1.add(b6);

		b7 = new JButton("Diabari :fair 11000 BDT per month");
		b7.setFont(new Font("Comic Sans MS",Font.BOLD,15));
		b7.setForeground(Color.red);
		b7.setBounds(100,400,500,30);
		b7.addActionListener(this);
		p1.add(b7);

		b12 = new JButton("Main Menu");
		b12.setFont(new Font("Comic Sans MS",Font.BOLD,15));
		b12.setForeground(Color.BLACK);
		b12.setBounds(100,450,250,25);
		b12.addActionListener(this);
		p1.add(b12);

		b13 = new JButton("EXIT");
		b13.setFont(new Font("Comic Sans MS",Font.BOLD,15));
		b13.setForeground(Color.BLACK);
		b13.setBounds(400,450,100,25);
		b13.addActionListener(this);
		p1.add(b13);

        l2 = new JLabel();
		l2.setFont(new Font("Serif",Font.BOLD,30));
		l2.setForeground(Color.BLUE);
		l2.setBounds(200,500,500,50);
		p1.add(l2);


		this.add(p1);
		
	}
  public void actionPerformed(ActionEvent ae)
    {
        if(ae.getSource()==b13)
            {
            
                System.exit(0);
            }
            else if(ae.getSource()==b1)
            {
            l2.setText("Registered to Mirpur, fair 13000 ");
            }
            else if(ae.getSource()==b12)
            {
            Student st=new Student();
            this.setVisible(false);
            st.setVisible(true);
            }
            else if(ae.getSource()==b2)
            {
            l2.setText("Registered to Gulshan, fair 12000 ");
            }
            else if(ae.getSource()==b3)
            {
            l2.setText("Registered to Dhandondi, fair 15000 ");
            }
            else if(ae.getSource()==b4)
            {
            l2.setText("Registered to Cantonment, fair 18000 ");
            }
            else if(ae.getSource()==b5)
            {
            l2.setText("Registered to Uttara, fair 24000 ");
            }
            else if(ae.getSource()==b6)
            {
            l2.setText("Registered to Basundhara, fair 20000 ");
            }
            else if(ae.getSource()==b7)
            {
            l2.setText("Registered to Diabari, fair 11000 ");
            }

    }


}