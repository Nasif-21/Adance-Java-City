public class run6 
{
	public static void main(String [] args)
	{
		Others h1 = new Others();
		h1.show();
		//f1.setVisible(true);
	}
}
