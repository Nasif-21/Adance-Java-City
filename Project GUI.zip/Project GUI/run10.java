public class run10
{
	public static void main(String [] args)
	{
		Deposit d1 = new Deposit();
		d1.show();
		
	}
}