import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Famous extends JFrame implements ActionListener
{
		JLabel l1,l2,l3,l4;
		//JTextField t1,t2;
		JButton b1,b2,b3,b4,b5,b6; 
		JPanel p1;
		
	public Famous()
	{
		super(" Famous Place  ");
		this.setSize(800,700);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		p1 = new JPanel();
		p1.setSize(new Dimension(800,700));
		p1.setBackground(Color.white);
		p1.setLayout(null);
		
		l1 = new JLabel("Famous Place ");
		l1.setFont(new Font("Serif",Font.BOLD,30));
		l1.setForeground(Color.BLUE);
		l1.setBounds(200,30,300,30);
		p1.add(l1);
		
		l2 = new JLabel("");
		l2.setFont(new Font("Comic Sans MS",Font.PLAIN,15));
		l2.setForeground(Color.red);
		l2.setBounds(50,450,800,20);
		p1.add(l2);
       

        l3 = new JLabel("");
		l3.setFont(new Font("Comic Sans MS",Font.PLAIN,15));
		l3.setForeground(Color.red);
		l3.setBounds(50,470,800,20);
		p1.add(l3); 
        

        l4 = new JLabel("");
		l4.setFont(new Font("Comic Sans MS",Font.PLAIN,15));
		l4.setForeground(Color.red);
		l4.setBounds(50,490,800,20);
		p1.add(l4); 

		
		b1 = new JButton("Lal Bager Kella");
		b1.setFont(new Font("Comic Sans MS",Font.BOLD,15));
		b1.setForeground(Color.green);
		b1.setBounds(180,100,300,25);
		b1.addActionListener(this);
		p1.add(b1);

				
		
		b2 = new JButton("Ahsan Monjhil");
		b2.setFont(new Font("Comic Sans MS",Font.BOLD,15));
		b2.setForeground(Color.red);
		
		b2.setBounds(180,150,300,30);
		b2.addActionListener(this);
		p1.add(b2);	


		b3 = new JButton("Hathir Jhil ");
		b3.setFont(new Font("Comic Sans MS",Font.BOLD,15));
		b3.setForeground(Color.black);
		
		b3.setBounds(180,200,300,30);
		b3.addActionListener(this);
		p1.add(b3);	

		b4 = new JButton("National Museum");
		b4.setFont(new Font("Comic Sans MS",Font.BOLD,15));
		b4.setForeground(Color.green);
		
		b4.setBounds(180,250,300,30);
		b4.addActionListener(this);
		p1.add(b4);	

		b5 = new JButton("Dhaka Zoo");
		b5.setFont(new Font("Comic Sans MS",Font.BOLD,15));
		b5.setForeground(Color.blue);
		
		b5.setBounds(180,300,300,30);
		b5.addActionListener(this);
		p1.add(b5);	

		b6= new JButton("Main Menu");
		b6.setFont(new Font("Comic Sans MS",Font.BOLD,15));
		b6.setForeground(Color.black);
		
		b6.setBounds(180,350,300,30);
		b6.addActionListener(this);
		p1.add(b6);	
		
        this.add(p1);		
       
	}

		public void actionPerformed(ActionEvent ae)
		{
			if(ae.getSource()==b1)
			
			{
			 

			 l2.setText("Lalbagh Fort (Fort Aurangabad) is an incomplete Mughal Palace fortress at Dhaka on the Buriganga River ");
			 l3.setText("in the southwestern part of the old city of Dhaka. Prince Muhammad Azam,son of Emperor Aurangzeb, "); 
			 l4.setText(" the construction while he was serving as the Viceroy of Bengal. Built in 17th Century dated 1678.");  

			}
			else if (ae.getSource()==b2)
			{
			  l2.setText(" Ahsan Manzil was the official residential palace and seat of the Nawab of Dhaka. The building is ");
			  l3.setText(" situated at Kumartoli along the banks of the Buriganga River in Dhaka, Bangladesh.Construction was ");
			  l4.setText("was started in 1859");	
			}

			else if (ae.getSource()==b4)
			{
				l2.setText("The museum is well organized and displays have been housed chronologically in several departments");
				l3.setText("like department of ethnography and decorative art, department of history and classical art, ");
				l4.setText("department of natural history, and department of contemporary and world civilization.");

			}
			else if (ae.getSource()==b3)
			{
				l2.setText("Legend has it that the elephants of Dhaka's Pilkhana used to take baths in these wetlands ");
				l3.setText("hence the name Hatirjheel.Architect Iqbal Habib, who heads the consultant firm of the Hatirjheel");
				l4.setText("the Hatirjheel-Begunbari development project,said that the Bhawal Raja used to keep his tamed elephants at Pilkhana.");
			}

			else if (ae.getSource()==b5)
			{
				l2.setText(" Bangladesh National Zoo is a zoo located in the Mirpur section of Dhaka, the capital city of ");
				l3.setText(" Bangladesh. The zoo contains many native and non-native animals and wild life, and hosts about three million visitors each year.");
				l4.setText("three million visitors each year.");
			}

			else if (ae.getSource()==b6)
			{
				Tourist i = new Tourist();
		           i.show();
			}


            
			}
		
			
				
			}





