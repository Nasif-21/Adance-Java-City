import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Tourist extends JFrame  implements ActionListener
{
  JButton b1,b2,b3,b4;
  JPanel p1;
   public Tourist()
    {
        super(" Tourist ");
        this.setSize(800,700);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        p1 = new JPanel();
		p1.setSize(new Dimension(800,700));
		p1.setBackground(Color.WHITE);
		p1.setLayout(null);



        b1 = new JButton("Trasport Facility");
		b1.setFont(new Font("Comic Sans MS",Font.BOLD,15));
		b1.setForeground(Color.green);
		b1.setBounds(300,100,250,60);
		b1.addActionListener(this);
		p1.add(b1);

		b2 = new JButton("Hotel Facility");
		b2.setFont(new Font("Comic Sans MS",Font.BOLD,15));
		b2.setForeground(Color.blue);
		b2.setBounds(300,200,250,60);
		b2.addActionListener(this);
		p1.add(b2);

		b3 = new JButton("Famous places");
		b3.setFont(new Font("Comic Sans MS",Font.BOLD,15));
		b3.setForeground(Color.red);
		b3.setBounds(300,300,250,60);
		b3.addActionListener(this);
		p1.add(b3);

		b4 = new JButton("EXIT");
		b4.setFont(new Font("Comic Sans MS",Font.BOLD,15));
		b4.setForeground(Color.BLACK);
		b4.setBounds(350,400,100,25);
		b4.addActionListener(this);
		p1.add(b4);
		this.add(p1);
	}
  public void actionPerformed(ActionEvent ae)
    {
        if(ae.getSource()==b1)
            {
             Transport tr=new Transport();
             this.setVisible(false);
             tr.setVisible(true);
            }
            else if(ae.getSource()==b3)
            {
                   Famous p=new Famous();
                    p.show();
        
            }
            else if(ae.getSource()==b2)
            	{
            Hotel ht=new Hotel();
            this.setVisible(false);
            ht.setVisible(true);
            }
            
            else if(ae.getSource()==b4)
            {
            	System.exit(0);
            }
    }


}