import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Submit extends JFrame //actionPerformed(ActionEvent ae)
		

         
{
		JLabel l1;
		//JTextField t1,t2,t3;
		//JButton b1,b2; 
		JPanel p1;
		
	public Submit()
	{
       super(" P ");
		this.setSize(800,700);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		p1 = new JPanel();
		p1.setSize(new Dimension(800,700));
		p1.setBackground(Color.white);
		p1.setLayout(null);

		l1 = new JLabel("Your responsed has been recorded");
		l1.setFont(new Font("Serif",Font.BOLD,30));
		l1.setForeground(Color.BLUE);
		l1.setBounds(100,200,500,30);
		p1.add(l1);
		 this.add(p1);

	}
}