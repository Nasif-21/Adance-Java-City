public class Test 
{
	public static void main(String [] args)
	{
		Log g1 = new Log();
		g1.show();
		//f1.setVisible(true);
	}
}