
public class ac1
{
	public static void main(String [] args)
	{
		 Account x=new Account();
	    	x.show();
		
	}
}