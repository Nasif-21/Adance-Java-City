import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Police extends JFrame implements ActionListener
{
		JLabel l1;
		//JTextField t1,t2;
		JButton b1,b2,b3,b4,b5; 
		JPanel p1;
		
	public Police()
	{
		super(" Police ");
		this.setSize(800,700);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		p1 = new JPanel();
		p1.setSize(new Dimension(450,280));
		p1.setBackground(Color.white);
		p1.setLayout(null);
		
		l1 = new JLabel("Police Service");
		l1.setFont(new Font("Serif",Font.BOLD,40));
		l1.setForeground(Color.RED);
		l1.setBounds(190,100,300,80);
		p1.add(l1);
		
		
		b1 = new JButton("Contact");
		b1.setFont(new Font("Comic Sans MS",Font.BOLD,15));
		b1.setForeground(Color.black);
		b1.setBounds(220,200,100,25);
		b1.addActionListener(this);
		p1.add(b1);

		b2 = new JButton("Complain");
		b2.setFont(new Font("Comic Sans MS",Font.BOLD,15));
		b2.setForeground(Color.black);
		b2.setBounds(220,250,100,25);
		b2.addActionListener(this);
		p1.add(b2);

		b3 = new JButton(" Rules and Regulations");
		b3.setFont(new Font("Comic Sans MS",Font.BOLD,15));
		b3.setForeground(Color.blue);
		b3.setBounds(180,300,200,25);
		b3.addActionListener(this);
		p1.add(b3);
		
		b4 = new JButton("Next");
		b4.setFont(new Font("Comic Sans MS",Font.BOLD,15));
		b4.setForeground(Color.black);
		b4.setBackground(Color.blue);
		b4.setBounds(330,400,130,30);
		b4.addActionListener(this);
		p1.add(b4);	

		b5 = new JButton("Main Menu");
		b5.setFont(new Font("Comic Sans MS",Font.BOLD,15));
		b5.setForeground(Color.black);
		b5.setBackground(Color.blue);
		b5.setBounds(100,400,130,30);
	    b5.addActionListener(this);
		p1.add(b5);	
		
		
        this.add(p1);		
        
	}
	public void actionPerformed(ActionEvent ae)
		{
			if(ae.getSource()==b1)
			{
			Contact a1=new Contact();
			a1.show();
			  
			}
			else if(ae.getSource()==b2)
			{
				Complain o1 = new Complain();
		        o1.show();
			}
		  else if(ae.getSource()==b3)
		  {
		  	Rules d1 = new Rules();
		      d1.show();
		  }
		  else if (ae.getSource()==b5)
		  {
		  	Permanent e1 = new Permanent();
		           e1.show();
		  }	
		}

		


}




