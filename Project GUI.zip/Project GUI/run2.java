public class run2 
{
	public static void main(String [] args)
	{
		Murder u1 = new Murder();
		u1.show();
		//f1.setVisible(true);
	}
}




