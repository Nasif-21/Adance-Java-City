
public class d1
{
	public static void main(String [] args)
	{
		 Domestic d=new Domestic();
		d.show();
		
	}
}