public class run3 
{
	public static void main(String [] args)
	{
		Complain u1 = new Complain();
		u1.show();
		//f1.setVisible(true);
	}
}
