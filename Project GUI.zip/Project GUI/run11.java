public class run11
{
	public static void main(String [] args)
	{
		Loan s1 = new Loan();
		s1.show();
		
	}
}