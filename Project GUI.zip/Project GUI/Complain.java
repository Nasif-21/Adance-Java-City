import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Complain extends JFrame implements ActionListener
{
		JLabel l1;
		
		JButton b1,b2,b3,b4,b5; 
		JPanel p1;
		
	public Complain()
	{
		super(" P ");
		this.setSize(800,700);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		p1 = new JPanel();
		p1.setSize(new Dimension(800,700));
		p1.setBackground(Color.white);
		p1.setLayout(null);
		
		l1 = new JLabel("Complain");
		l1.setFont(new Font("Serif",Font.BOLD,40));
		l1.setForeground(Color.BLUE);
		l1.setBounds(220,30,200,40);
		p1.add(l1);

		b1 = new JButton("Murder Case");
		b1.setFont(new Font("Comic Sans MS",Font.BOLD,15));
		b1.setForeground(Color.green);
		b1.setBounds(220,100,190,40);
		b1.addActionListener(this);
		p1.add(b1);

		b2 = new JButton("Theif Case");
		b2.setFont(new Font("Comic Sans MS",Font.BOLD,15));
		b2.setForeground(Color.green);
		b2.setBounds(220,150,190,40);
		b2.addActionListener(this);
		p1.add(b2);

		b3 = new JButton("Lost Case");
		b3.setFont(new Font("Comic Sans MS",Font.BOLD,15));
		b3.setForeground(Color.green);
		b3.setBounds(220,200,190,40);
		b3.addActionListener(this);
		p1.add(b3);

		b4= new JButton(" Other Case");
		b4.setFont(new Font("Comic Sans MS",Font.BOLD,15));
		b4.setForeground(Color.green);
		b4.setBounds(220,250,190,40);
		b4.addActionListener(this);
		p1.add(b4);

		b5 = new JButton("Main menu");
		b5.setFont(new Font("Comic Sans MS",Font.BOLD,15));
		b5.setForeground(Color.green);
		b5.setBounds(220,300,190,40);
		b5.addActionListener(this);
		p1.add(b5);

		this.add(p1);
	}
	public void actionPerformed(ActionEvent ae)
		{
			if(ae.getSource()==b5)
			{
			
			  Police s1 = new Police();
		       s1.show();
			}
			else if(ae.getSource()==b1)
			{
				Murder u1 = new Murder();
		        u1.show();
				
			}
			else if(ae.getSource()==b2)
			{
				Theif m1 = new Theif();
		            m1.show();
			}
			else if(ae.getSource()==b3)
			{
				Lost u1 = new Lost();
		          u1.show();
			}
			else if(ae.getSource()==b4)
			{
				Others h1 = new Others();
		          h1.show();
			}


		}

		


}


