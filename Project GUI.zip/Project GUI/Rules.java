import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Rules extends JFrame implements ActionListener
{
		JLabel l1,l2,l3,l4,l5,l6;
		JButton b1;
		
		JPanel p1;
		
	public Rules()
	{
		super(" rules page ");
		this.setSize(800,700);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		p1 = new JPanel();
		p1.setSize(new Dimension(800,700));
		p1.setBackground(Color.white);
		p1.setLayout(null);
		
		l1 = new JLabel("Rules And Regulatios ");
		l1.setFont(new Font("Serif",Font.BOLD,30));
		l1.setForeground(Color.BLUE);
		l1.setBounds(180,30,300,30);
		p1.add(l1);
		
		l2 = new JLabel("1. Don't drive without licence");
		l2.setFont(new Font("Comic Sans MS",Font.PLAIN,20));
		l2.setForeground(Color.green);
		l2.setBounds(100,100,400,20);
		p1.add(l2);
		
		l3 = new JLabel("2. Don't break any traffic rules.");
		l3.setFont(new Font("Comic Sans MS",Font.PLAIN,20));
		l3.setForeground(Color.green);
		l3.setBounds(100,150,400,20);
		p1.add(l3);
		
		
		l4 = new JLabel(" 3.Don't take or carry any drugs or similar subtance");
		l4.setFont(new Font("Comic Sans MS",Font.PLAIN,20));
		l4.setForeground(Color.green);
		l4.setBounds(100,200,550,20);
		p1.add(l4);

		l5 = new JLabel("4.Women abuse is prohibited .");
		l5.setFont(new Font("Comic Sans MS",Font.PLAIN,20));
		l5.setForeground(Color.green);
		l5.setBounds(100,250,400,20);
		p1.add(l5);

		l6 = new JLabel(" 5.Children abuse is banned");
		l6.setFont(new Font("Comic Sans MS",Font.PLAIN,20));
		l6.setForeground(Color.green);
		l6.setBounds(100,300,450,20);
		p1.add(l6);

		b1 = new JButton("Main menu");
		b1.setFont(new Font("Comic Sans MS",Font.BOLD,15));
		b1.setForeground(Color.black);
		b1.setBounds(220,400,200,25);
		b1.addActionListener(this);
		p1.add(b1);

		
		
        this.add(p1);		
        
	}
	 public void actionPerformed(ActionEvent ae)
        {
            if(ae.getSource()==b1)
            {
                Permanent e1 = new Permanent();
		               e1.show();
            }

}

}

