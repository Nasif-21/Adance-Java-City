public class run4 
{
	public static void main(String [] args)
	{
		Theif m1 = new Theif();
		m1.show();
		//f1.setVisible(true);
	}
}
