public class t1
{
	public static void main(String [] args)
	{
		Tourist i = new Tourist();
		           i.show();
		
	}
}


